﻿=== The HOI4 (Hearts of Iron 4) Cursor Set ===

By: Skibidi guy (http://www.rw-designer.com/user/119731)

Download: http://www.rw-designer.com/cursor-set/the-hoi4-hearts-of-iron-4-cursor

Author's description:

This is the HOI4 cursors!

Note that some of the cursor can become hard to understand if you dont play the game, or even if you play HOI4

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.